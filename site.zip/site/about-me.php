<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header("Location: loginscreen.html");
    exit;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="homestyle.css">
</head>
<body>
    <div class="headertext">
        <div>
            <a href="logout.php">Logout</a>
        </div>
        <div>
           <p class="w3-monospace"> 
                <a href="home.php">Home</a> 
                <a href="videos.php">Videos</a>
                <a href="lists.php">Lists</a>
                <a href="about-me.php">About Me</a>
            </p>
        </div>
    </div>
    <label class="toggle-switch">
        <input type="checkbox" onclick="toggleDarkMode()">
        <span class="toggle-slider"></span>
    </label>

    <div class="lol">
        <h1 class="w3-monospace">Welcome to the Worlds Most Useless Website</h1>
        <h2 class="w3-monospace">About me</h2>
    </div>

    <div class="wtf">
        <p class="w3-monospace">My name is Joshua Caley, I'm currently enrolled at SIUE, and I designed this website to use things I learned in class, 
            and also new things so I could design a basic but clean looking website with basic functions 
            for things that I enjoy doing.</p>
        <p class="w3-monospace">The hardest thing for me to get down was getting dark mode to work,
            I would like it so that it would stay when changing links once you've selected.</p>
    </div>

    <script>
        function toggleDarkMode() {
            const body = document.body;
            body.classList.toggle('dark-mode');
        }
    </script>

    
</body>
</html>
