<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header("Location: loginscreen.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="homestyle.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="headertext">
        <div>
            <a href="logout.php">Logout</a>
        </div>
        <div>
           <p class="w3-monospace"> 
                <a href="home.php">Home</a> 
                <a href="videos.php">Videos</a>
                <a href="lists.php">Lists</a>
                <a href="about-me.php">About Me</a>
            </p>
        </div>
    </div>
    <br><br><br>

    <label class="toggle-switch">
        <input type="checkbox" onclick="toggleDarkMode()">
        <span class="toggle-slider"></span>
    </label>

    <script>
        function toggleTextBoxes() {
            const textBoxContainer = document.getElementById('text-box-container');
            textBoxContainer.style.display = (textBoxContainer.style.display === 'block') ? 'none' : 'block';
        }

        function toggleDarkMode() {
            const body = document.body;
            body.classList.toggle('dark-mode');
        }
    </script>
    <div class="video-container">
    <?php

    $videoDir = "fotos/";

    $videoFiles = glob($videoDir . "*.{mp4,webm,ogg}", GLOB_BRACE);

    if ($videoFiles) {
        foreach ($videoFiles as $videoPath) {
            echo '<div class="video-box">
                    <video controls>
                        <source src="' . $videoPath . '" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>';
            }
        } 
        else {
            echo "No videos uploaded yet.";
            }
    ?>
    </div>
    <div class="uploadbutton">
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <label for="fileUpload"><p class="w3-monospace">Choose File</p></label>
            <input type="file" id="fileUpload" name="videoFile">
            <input type="submit" value="Upload" name="submit">
        </form>
    </div>

</form>


</ul>
</body>
</html>
