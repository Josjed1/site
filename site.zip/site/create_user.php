<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $dsn = 'mysql:host=localhost;dbname=testing';
    $username_db = 'root';
    $password_db = 'root';

    try {
        $pdo = new PDO($dsn, $username_db, $password_db);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $createTableQuery = "CREATE TABLE IF NOT EXISTS registration(
            id INT(10) NOT NULL AUTO_INCREMENT,
            username VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            PRIMARY KEY(id)
        )";

        $pdo->exec($createTableQuery);

        $checkUsernameQuery = "SELECT username FROM users WHERE username = :username";
        $checkStmt = $pdo->prepare($checkUsernameQuery);
        $checkStmt->bindParam(':username', $username);
        $checkStmt->execute();
        $existingUsername = $checkStmt->fetchColumn();

        if ($existingUsername) {
            echo "Username already exists!";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

            $insertQuery = "INSERT INTO users (username, password) VALUES (:username, :password)";
            $stmt = $pdo->prepare($insertQuery);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $hashedPassword);

            if ($stmt->execute()) {
                header("Location: loginscreen.html");
            } else {
                echo "Error1";
            }
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

