<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $movieTitle = $_POST['movie_title'];
    $whereToWatch = $_POST['where_to_watch'];
    $dayToWatch = $_POST['day_to_watch'];


    $dsn = 'mysql:host=localhost;dbname=testing';
    $username = "root";
    $password = "root";

    try {
        $conn = new PDO($dsn, $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $createTableQuery = "CREATE TABLE IF NOT EXISTS movies(
            title VARCHAR(100) NOT NULL UNIQUE,
            watch VARCHAR(100) NOT NULL,
            calendar VARCHAR(100) NOT NULL,
            PRIMARY KEY(title)
        )";
        $conn->exec($createTableQuery);

        $insertQuery = "INSERT INTO movies (title, watch, calendar) VALUES (:movieTitle, :whereToWatch, :dayToWatch)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bindParam(':movieTitle', $movieTitle);
        $stmt->bindParam(':whereToWatch', $whereToWatch);
        $stmt->bindParam(':dayToWatch', $dayToWatch);
        $stmt->execute();


        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

$dsn = 'mysql:host=localhost;dbname=testing';
$username = "root";
$password = "root";

try {
    $conn = new PDO($dsn, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $selectQuery = "SELECT title, watch, calendar FROM movies";
    $stmt = $conn->query($selectQuery);
    $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage(); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="homestyle.css">

    <style>
        th {
            text-align: left;
            font-weight: bold;
            font-size: 1.2em;
        }
        h1 {
            text-align: left;
            margin-top: 60px;
            font-size: 2.5em;
        }

        .add-button {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
        }

        .text-box-container {
            display: none;
            position: fixed;
            bottom: 70px;
            left: 50%;
            transform: translateX(-50%);
            transition: all 0.3s ease;
        }

        .text-box {
            display: block;
            margin-bottom: 10px;
        }

        .submit-button {
            display: block;
            margin-bottom: 10px;
            position: fixed;
            bottom: 150px;
            left: 50%;
            transform: translateX(-50%);
        }
    </style>
</head>
<body>
    <div class="headertext">
        <div>
            <a href="logout.php">Logout</a>
        </div>
        <div>
           <p class="w3-monospace"> 
                <a href="home.php">Home</a> 
                <a href="videos.php">Videos</a>
                <a href="lists.php">Lists</a>
                <a href="about-me.php">About Me</a>
            </p>
        </div>
    </div>
    <label class="toggle-switch">
        <input type="checkbox" onclick="toggleDarkMode()">
        <span class="toggle-slider"></span>
    </label>
    <script>
        function toggleTextBoxes() {
            const textBoxContainer = document.getElementById('text-box-container');
            textBoxContainer.style.display = (textBoxContainer.style.display === 'block') ? 'none' : 'block';
        }

        function toggleDarkMode() {
            const body = document.body;
            body.classList.toggle('dark-mode');
        }

        function submitForm() {
            // Logic to handle form submission
        }
    </script>

    <h1 class="w3-monospace">Movies List</h1>
    <table class="w3-table w3-bordered">
        <?php if (isset($movies) && !empty($movies)) : ?>
            <tr>
                <th>Title</th>
                <th>Where to Watch</th>
                <th>Day</th>
            </tr>
            <?php foreach ($movies as $movie) : ?>
                <tr>
                    <td><?= $movie['title']; ?></td>
                    <td><?= $movie['watch']; ?></td>
                    <td><?= $movie['calendar']; ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr>
                <td colspan="3">No movies found</td>
            </tr>
        <?php endif; ?>
    </table>

    <button class="w3-button w3-circle w3-black add-button" onclick="toggleTextBoxes()">+</button>
    
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="text-box-container" id="text-box-container">
            <input type="text" class="text-box" name="movie_title" placeholder="Movie Title">
            <input type="text" class="text-box" name="where_to_watch" placeholder="Where to Watch">
            <input type="text" class="text-box" name="day_to_watch" placeholder="Day to Watch">
            <button type="submit" class="submit-button w3-button w3-black" onclick="submitForm()">Submit</button>
        </div>
    </form>
</body>
</html>