<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header("Location: loginscreen.html");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['videoFile'])) {
    $targetDir = "fotos/";
    $targetFile = $targetDir . basename($_FILES['videoFile']['name']);

    $videoFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    if ($videoFileType !== "mp4" && $videoFileType !== "webm" && $videoFileType !== "ogg") {
        header("Location: videos.php");
        exit;
    }
    if (move_uploaded_file($_FILES['videoFile']['tmp_name'], $targetFile)) {
       header("Location: videos.php");
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>