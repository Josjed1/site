<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .wtf-container {
            display: flex;
            justify-content: space-between; 
            width: 100%;
        }
        .left-list {
            width: 48%; 
        }
        .right-list {
            width: 48%;
        }
        .left-title {
            margin-left: 15px;
        }
        .right-title {
            text-align: right;
            margin-right: 10px;
            font: w3-mono
        }
        .right-list ul {
            text-align: right; 
        }
        .right-list .w3-bar-item {
            text-align: right; 
        }
        /* New styles for aligning image and text on the right list */
        .right-list .w3-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }
        .right-list .w3-bar .w3-bar-item {
            text-align: left; 
            margin-right: 10px; 
        }
    </style>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="homestyle.css">
</head>
<body>




    <div class="headertext">
        <div>
            <a href="logout.php">Logout</a>
        </div>
        <div>
           <p class="w3-monospace"> 
                <a href="home.php">Home</a> 
                <a href="videos.php">Videos</a>
                <a href="lists.php">Lists</a>
                <a href="about-me.php">About Me</a>
            </p>
        </div>
    </div>




    <label class="toggle-switch">
        <input type="checkbox" onclick="toggleDarkMode()">
        <span class="toggle-slider"></span>
    </label>



    <div class="lol">
        <h1 class="w3-monospace">Welcome</h1>
    </div>



    <div class="wtf-container">
        <div class="left-list">
            <div class="left-title"><h2 class="w3-monospace">Tech/Gaming News</h2></div>
            <ul class="w3-ul w3-card-4 w3-border w3-hoverable">
                <a href="https://www.counter-strike.net/news/update">
                    <li class="w3-bar">
                        <img src="Logos/CS.png" class="w3-bar-item w3-circle" style="width:85px"."right:25px">
                        <div class="w3-bar-item">
                            <span class="w3-large">Counter Strike</span><br>
                            <span>Game News</span>
                        </div>
                    </li>
                </a>
                <a href="https://www.gameinformer.com">
                    <li class="w3-bar">
                        <img src="Logos/gameinformer.png" class="w3-bar-item w3-circle" style="width:85px">
                        <div class="w3-bar-item">
                            <span class="w3-large">Game Informer</span><br>
                            <span>Game News</span>
                        </div>
                    </li>
                </a>
                <a href="https://www.youtube.com/@penguinz0">
                    <li class="w3-bar">
                        <img src="Logos/Moist.png" class="w3-bar-item w3-circle" style="width:85px">
                        <div class="w3-bar-item">
                            <span class="w3-large">moistcr1tikal</span><br>
                            <span>Media News/Game News</span>
                        </div>
                    </li>
                </a>
            </ul>
        </div>




        <div class="right-list">
            <div class="right-title"><h2 class="w3-monospace">General News</h2></div>
            <ul class="w3-ul w3-card-4 w3-border w3-hoverable">
                <!-- Sample items for General News -->
                <a href="https://www.thedailybugle.net">
                    <li class="w3-bar">
                        <div class="w3-bar-item">
                            <span class="w3-large">The Daily Bugel</span><br>
                            <span>Spiderman News</span>
                        </div>
                        <img src="Logos/Daily.png" class="w3-bar-item w3-circle" style="width:85px">
                    </li>
                </a>
                <a href="https://www.espn.com">
                    <li class="w3-bar">
                        <div class="w3-bar-item">
                            <span class="w3-large">ESPN</span><br>
                            <span>Sports News</span>
                        </div>
                        <img src="Logos/espn.png" class="w3-bar-item w3-circle" style="width:85px">
                    </li>
                </a>
                <a href="https://www.reuters.com">
                    <li class="w3-bar">
                        <div class="w3-bar-item">
                            <span class="w3-large">Reuters</span><br>
                            <span>Global News</span>
                        </div>
                        <img src="Logos/Reuters.png" class="w3-bar-item w3-circle" style="width:85px">
                    </li>
                </a>
            </ul>
        </div>
    </div>




    <script>
        function toggleDarkMode() {
            const body = document.body;
            body.classList.toggle('dark-mode');
        }
    </script>
</body>
</html>
